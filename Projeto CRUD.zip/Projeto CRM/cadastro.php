<?php

    date_default_timezone_set('America/Sao_Paulo');
    $dataAtual = date('Y-m-d');    

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css\style.css">
    <title>Cadastro</title>
    <link rel="icon" type="image/x-icon" href="images/cadastro.png">
    <script src="js/formulario.js"></script>

</head>
<body>
    <div id="container">
        <div id="header">
            <h1>Cadastro de Usuários</h1>
        </div>
        <form name="formCadastro" action="cadastrar.php" method="POST" onsubmit="return validaFormulario()">
        <div id="Cad">
            <div id="linhas">
                <div>
                    <label><strong>Nome:</strong></label>
                    <input class="campo" type="text" name="nome" id="nome"/><br>
                </div>
                <div>
                    <label><strong>Senha:</strong></label>
                    <input class="campo" type="password" name="senha" id="senha"/><br>
                </div>
                <div>
                    <label><strong>Telefone:</strong></label>
                    <input class="campo" name="telefone" type="tel" id="telefone"/><br>
                </div>
                <div>
                    <label><strong>Email:</strong></label>
                    <input class="campo" name="email" type="email" id="email"/><br>
                </div>
                <div>
                    <label><strong>Endereço:</strong></label>
                    <input class="campo" name="endereco" type="text" id="endereco"/><br>
                </div>
                <div>
                    <label><strong>Gênero:</strong></label>
                    <select class="campo" name="genero" id="genero" style=>

                        <option value="Selecionar">Selecione seu genero</option>
                        <option value="Masculino">Masculino</option>
                        <option value="Feminino">Feminino</option>
                        <option value="Outro">Outro</option>
                        <option value="Prefiro não especificar">Prefiro não especificar</option>
                    </select><br>
                </div>
                <div>
                    <label><strong>Nascimento:</strong></label>
                    <input class="campo" type="date" name="data_nascimento" id="nascimento" value="" min="1921-01-01" max=<?php echo $dataAtual; ?>><br>
                </div>
                <div>
                    <input type="submit" class="botao" id="btCadastro" value="Cadastrar"><br>
                </div>
            </div>
        </div>
    </div>
    </form>
</body>
</html>