<?php
    
    include("conexao.php");
    date_default_timezone_set('America/Sao_Paulo');

    session_start();

    $nomeUsuario = $_SESSION['usuario'];

    $sql = "SELECT codigo FROM tbusuarios WHERE nome ='$nomeUsuario'";
    $codigo = mysqli_query($conexao, $sql);
    $resultado = mysqli_fetch_array($codigo);

    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao']; 
    $data = date('Y-m-d');
    $idusuario = $resultado['codigo'];
    $status = $_POST['status'];
    
    $sql = "INSERT INTO tbtarefa (titulo, descricao, data, idusuario, status) VALUES 
    ('$titulo', '$descricao', '$data', '$idusuario', '$status')";
    
    $cadastro = mysqli_query($conexao,$sql) or die('Em caso de erro nos contate');
      
    if ($cadastro) {
        

        echo("<script>window.alert('Tarefa Cadastrada!')</script>");
        echo("<script>window.location.href='lista.php'</script>");
            
    } else {
    
         die("Erro ao adicionar tarefa");
    
    }

?>