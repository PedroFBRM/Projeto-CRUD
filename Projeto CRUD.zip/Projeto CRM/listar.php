<?php
session_start();
require("conexao.php");

$usuario = $_SESSION['usuario'];

// Verificar se o parâmetro 'status' existe na requisição
if (isset($_GET['status'])) {
    $status = $_GET['status'];
    
    // Prevenir SQL Injection
    $status = $conexao->real_escape_string($status);

    // Montar a consulta SQL
    $sql = "SELECT * FROM tbtarefa WHERE idusuario = (SELECT codigo FROM tbusuarios WHERE nome = '$usuario')";

    if ($status !== 'S') {
        $sql .= " AND status = '$status'";
    }

    $result = mysqli_query($conexao, $sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["codigo"] . "</td>";
            echo "<td>" . $row["titulo"] . "</td>";
            echo "<td>" . $row["descricao"] . "</td>";
            echo "<td>" . $row["data"] . "</td>";
            echo "<td>" . $usuario . "</td>";

            $statusTexto = $row["status"] == "P" ? "Pendente" : "Concluído";
            $statusColor = $row["status"] == "P" ? "#c78f16" : "green";

            echo "<td style='color: $statusColor;'>" . $statusTexto . "</td>";
            echo "<td>";
            echo "<form name='utilitarios' action='utilitarios.php' method='POST'>";
            echo "<input type='text' name='codigo' id='codigo' value='" . $row["codigo"] . "' style='display: none'>";
            echo "<input class='botao' type='submit' name='funcao' id ='botaolist' value='Excluir'>";
            echo "<input class='botao' type='submit' name='funcao' id ='botaolist' value='Alterar'>";
            if ($row["status"] != "C") {
                echo "<input class='botao' type='submit' name='funcao' id ='botaolist' value='Entregar Tarefa'>";
            } else {
                echo "<input class='botao' type='submit' name='funcao' id ='botaolist' value='Estornar Entrega'>";
            }
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }
    } else {
        echo "Nenhuma tarefa encontrada.";
    }
} else {
    echo "Parâmetro 'status' não fornecido.";
}

$conexao->close();
?>
