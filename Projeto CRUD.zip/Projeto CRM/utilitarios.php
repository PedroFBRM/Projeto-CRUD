<?php

    include("conexao.php");
    session_start();
    require("teste_conexao.php");
 

    $funcao = $_POST['funcao'];
   
    $nomeUsuario = $_SESSION['usuario'];
    $codigo_tarefa = $_SESSION['codigo_tarefa'];


    if($funcao == "Excluir") {
        
        $codigo = $_POST['codigo'];
    
        $sql = "DELETE FROM tbtarefa WHERE codigo=$codigo";
       
        $delete = mysqli_query($conexao,$sql) or die('Em caso de erro nos contate!');
    
    
       if (!$delete) {

            die("Erro ao deletar");
      
        } else {

            echo("<script>window.alert('Tarefa Excluída Com Sucesso!')</script>");
            echo("<script>window.location.href='lista.php'</script>");

       } 
       
    } else if ($funcao == "Alterar") {

        $codigo = $_POST['codigo'];
        header("Location: editortarefa.php");
        session_start();
        $_SESSION['codigo_tarefa'] = $codigo;

    
    } else if($funcao == "Entregar Tarefa") {
        
        $codigo = $_POST['codigo'];
    
        $sql = "UPDATE tbtarefa set status='C' WHERE codigo='$codigo'";
        
        $editar = mysqli_query($conexao,$sql) or die('Em caso de erro nos contate');
        
        if ($editar) {
            

            echo("<script>window.alert('Tarefa Entregue!')</script>");
            echo("<script>window.location.href='lista.php'</script>");
         
        } else {
        
            die("Erro ao editar tarefa");
        
        }
    
    
    } else if($funcao == "Estornar Entrega") {
        $codigo = $_POST['codigo'];
        
        $sql = "UPDATE tbtarefa set status='P' WHERE codigo='$codigo'";
        
        $editar = mysqli_query($conexao,$sql) or die('Em caso de erro nos contate');
        
        if ($editar) {
            

            echo("<script>window.alert('Tarefa Estornada!')</script>");
            echo("<script>window.location.href='lista.php'</script>");
         
        } else {
        
            die("Erro ao editar tarefa");
        
        }
        
    
    
    }    else {

        $sql = "SELECT codigo FROM tbusuarios WHERE nome ='$nomeUsuario'";
        $codigo = mysqli_query($conexao, $sql);
        $resultado = mysqli_fetch_array($codigo);

        $titulo = $_POST['titulo'];
        $descricao = $_POST['descricao']; 
        $data = date('Y-m-d');
        $idusuario = $resultado['codigo'];
        $status = $_POST['status'];
    
        $sql = "UPDATE tbtarefa set titulo='$titulo', descricao='$descricao', data='$data', status='$status' WHERE codigo='$codigo_tarefa'";
        
        $editar = mysqli_query($conexao,$sql) or die('Em caso de erro nos contate');
        
        if ($editar) {
            

            echo("<script>window.alert('Tarefa Alterada com Sucesso!')</script>");
            echo("<script>window.location.href='lista.php'</script>");
         
        } else {
        
            die("Erro ao editar tarefa");
        
        }

  }



?>