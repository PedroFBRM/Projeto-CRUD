function sair(){

    if (confirm("Deseja realmente Sair?") == true) {
        window.location.href='sair.php'
      } 

}