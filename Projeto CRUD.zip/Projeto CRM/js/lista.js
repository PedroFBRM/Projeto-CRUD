function sair(){
        
    if (confirm("Deseja realmente Sair?") == true) {
        window.location.href='sair.php'
      } 

}

function recuperardados() {
  var nome = document.forms['busca']['buscador'].value;
  $.ajax({
      url: "listar.php",
      type: "GET",
      data: { status: buscador},
      beforeSend: function() {
          $("#conteudo").html("carregando os dados...");
      },
      success: function(data) {
          $("#conteudo").html(data);
      },
      error: function(xhr, status, error) {
          $("#conteudo").html("Erro ao carregar os dados.");
          console.error("Erro: " + error);
      }
  });
}