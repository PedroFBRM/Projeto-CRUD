function validaCadastroTarefa() {

  var mensagem="Preencha todos os campos:\n";
  var erro = 0;


  if(document.getElementById("titulo").value == ""){
    erro = 1;
    mensagem += "- Título\n";
    document.getElementById("titulo").focus();
}

if(document.getElementById("descricao").value == ""){
  erro = 1;
  mensagem += "- Descrição\n";
  document.getElementById("descricao").focus();
}

if(document.getElementById("status").value == "Selecionar"){
  erro = 1;
  mensagem += "- Status\n";
  document.getElementById("status").focus();
}



  if(erro == 1) {

      window.alert(mensagem);
      return false;


  } else {

      return true;

  }

}