function validaFormulario(){

    var validador = "Complete os seguinte campos:\n";
    var erro = 0;
  
    if(document.formCadastro.nome.value == "") {

        validador+="- Nome\n";
        document.getElementById('nome').focus();
        erro = 1;

    } 

    if(document.formCadastro.senha.value == "") {

        validador+="- Senha\n";
        document.getElementById('senha').focus();
        erro = 1;

    }

    if(document.formCadastro.email.value == "") {

        validador+="- Email\n";
        document.getElementById('email').focus();
        erro = 1;

    }

    if(document.formCadastro.genero.value == "Selecionar") {

        validador+="- Gênero\n";
        document.getElementById('genero').focus();
        erro = 1;

    }

    if(document.formCadastro.nascimento.value == "") {

       validador+="- Nascimento\n";
        document.getElementById('nascimento').focus();
       erro = 1;

     }
    


    if(erro == 1) {
        alert(validador);
        return false;
    } else {
        return true;
        
    }
 
}