function validaEntrada() {

    var mensagem = "Preencha os campos:\n";
    var erro = 0;

    if(document.getElementById("nome").value == ""){
        erro = 1;
        mensagem += "- Usuário\n";
        document.getElementById("nome").focus();
    }

    if(document.getElementById("senha").value == ""){
        erro = 1;
        mensagem += "- Senha\n";
        document.getElementById("senha").focus();
    }


    
}