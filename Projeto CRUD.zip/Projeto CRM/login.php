<?php


    include("conexao.php");

    session_start();

    $usuario = $_POST['nome'];
    $senha = $_POST['senha'];

        $sql = $conexao->prepare("SELECT nome, senha FROM tbusuarios WHERE nome=? AND senha=?");

        $sql->bind_param("ss",$usuario,$senha);
        $login = $sql->execute();

        if ($login) {

            $resultado = $sql-> get_result();
            $resultadoFinal = mysqli_num_rows($resultado);


            if($resultadoFinal > 0) {

            
                    $_SESSION['usuario'] = $usuario;
                    $_SESSION['senha'] = $senha;
                    echo("<script>window.alert('Login realizado!')</script>");
                    echo("<script>window.location.href='lista.php'</script>");

                } else {

                    unset($_SESSION['usuario']);
				    unset($_SESSION['senha']);
                    session_destroy();
                    echo("<script>window.alert('Conta não encontrada! Verificar usuário ou senha!')</script>");
                    echo("<script>window.location.href='Index.php'</script>");

                }
        }
    

?>