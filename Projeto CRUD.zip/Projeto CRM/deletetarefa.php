<?php

session_start();
require("teste_conexao.php");

include("conexao.php");

    if($novatarefa){

        $sql = "DELETE FROM tbtarefa ORDER BY codigo DESC LIMIT 1";
       

        $delete = mysqli_query($conexao,$sql) or die('Em caso de erro nos contate');
      
    
    
       if (!$delete) {
    
            die("Erro ao deletar");
    
       }
       
    }else{
        $codigo = $_POST['codigo'];    

        $sql = "DELETE FROM tbtarefa WHERE codigo = $codigo";
       
     
        $delete = mysqli_query($conexao,$sql) or die('Em caso de erro nos contate');
      
    
    
       if ($delete) {
       
            echo "";
    
       } else {
    
            die("Erro ao deletar");
    
       }
    }















?>