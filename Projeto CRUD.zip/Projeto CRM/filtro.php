<?php

    include ("conexao.php");
    session_start();
    require("teste_conexao.php");
    include("ajx.js");

    $sql = "SELECT * FROM tbtarefa WHERE idusuario=(SELECT codigo from tbusuarios where nome='$usuario')";
        $lista = mysqli_query($conexao, $sql);
        $listagem = mysqli_fetch_array($lista);
        
        $codigo = $listagem['codigo'];
        $titulo = $listagem['titulo'];
        $descricao = $listagem['descricao'];
        $status = $listagem['status'];

        getDados($codigo, $titulo, $descricao, $status);

?>