<?php

 
  session_start();
   require("conexao.php");
  require("teste_conexao.php");
  
  $usuario = $_SESSION['usuario'];
  $senha = $_SESSION['senha'];
  $sql = "SELECT * FROM tbtarefa WHERE idusuario=(SELECT codigo from tbusuarios where nome='$usuario')";
  $lista = mysqli_query($conexao, $sql);


?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Lista de Tarefas</title>
  <link rel="icon" type="image/x-icon" href="images/lista.png">
  <link rel="stylesheet" href="css\style.css">
  <script src="js\lista.js"></script>
</head>

<body>



  <div class="container">
    <button onclick="return sair()" class = "botao" id = "sair">Sair</button>
    <div class="header">
      <span>Cadastro de Tarefas</span>
    </div>

    <div class="divTable">
      <table>
        <thead>
          <tr>
            <th>Codigo</th>
            <th>Título</th>
            <th>Descrição</th>
            <th>Data de criação</th>
            <th>Usuário</th>
            <th>Status</th>
            <th style = "text-align: center" ><a href="cadastro_tarefa.php"><button id="new">Adicionar</button></a></th>
         </tr>
         <?php
         while ($listagem = mysqli_fetch_array($lista)) {
          ?>
          <tr>
            <th>
              <?php
              $codigo = $listagem['codigo'];
              echo($codigo);
              ?>  
            </th>
              <th>
                <?php
                $titulo = $listagem['titulo'];
                echo($titulo);
                ?>
              </th>
              <th>
                <?php
                $descricao = $listagem['descricao'];
                echo($descricao);
                ?>
              </th>
              <th>
                <?php
                $data = $listagem['data'];
                echo($data);
                ?>
              </th>
              <th>
                <?php
                echo($usuario);
                ?>
              </th>
                <?php
                $status = $listagem['status'];
                switch($status) {

                  case "P":
                    $status = "Pendente";
                    break;

                  case "C":
                    $status = "Concluído";
                    break;
                }
                if($status == "Pendente") {

                ?>

                <th style="color: #c78f16;">

              <?php 
              
                  echo($status);
            } else if ($status == "Concluído") {?>
                <th style="color: green;">
              <?php 
                  echo($status);
            } ?>
              </th>
              <th>

                <form name="utilitarios" action="utilitarios.php" method="POST">
                  <input type="text" name="codigo" id="codigo" value=<?php echo($codigo)?> style="display: none">
                  <input class="botao" type="submit" name="funcao" id ="botaolist" value="Excluir">
                  <input class="botao" type="submit" name="funcao" id ="botaolist" value="Alterar">
                  <?php

                      if($status!="Concluído") {
                  ?>

                      <input class="botao" type="submit" name="funcao" id ="botaolist" value="Entregar Tarefa">

            <?php } else {?>

              <input class="botao" type="submit" name="funcao" id ="botaolist" value="Estornar Entrega"> 

            <?php } ?>

                </form>
                
                <?php } 
                ?>
           </tr>
       </thead>
      </table>           
    </div>
    <div class="modal-container">
      <div class="modal">
        <form action="addtarefa.php" method="POST">
          <label for="m-titulo">Título</label>
          <input id="m-titulo" type="text" required />

          <label for="m-descricao">Descrição</label>
          <textarea id="m-descricao" required></textarea>
          <label for="radio">Status</label>
          <div id="radio">
            <label for="m-statusPendente">Pendente</label>
            <input id="m-statusPendente" type="radio" required />
            <label for="m-statusConcluida">Concluída</label>
            <input id="m-statusConcluida" type="radio" required />        
         </div>
          <button id="btnSalvar">Salvar</button>
        </form>
      </div>
    </div>
  </div>
</body>

</html>
