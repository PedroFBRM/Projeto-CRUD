<?php


session_start();
require("conexao.php");
require("teste_conexao.php");

$usuario = $_SESSION['usuario'];
$senha = $_SESSION['senha'];
$sql = "SELECT * FROM tbtarefa WHERE idusuario=(SELECT codigo from tbusuarios where nome='$usuario')";
$lista = mysqli_query($conexao, $sql);


?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Lista de Tarefas</title>
  <link rel="icon" type="image/x-icon" href="images/lista.png">
  <link rel="stylesheet" href="css\style.css">
  <script src="js/lista.js"></script>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
    function recuperardados() {
      var status = document.forms['busca']['buscador'].value;
      $.ajax({
  url: "listar.php",  // Verifique se este caminho está correto
  type: "GET",
  data: { status: status },
  beforeSend: function() {
    $("#conteudo").html("carregando os dados...");
  },
  success: function(data) {
    $("#conteudo").html(data);
  },
  error: function(xhr, status, error) {
    $("#conteudo").html("Erro ao carregar os dados.");
    console.error("Erro: " + error);
  }
});

    }
  </script>
</head>

<body>
  <div class="container">
    <button onclick="return sair()" class="botao" id="sair">Sair</button>
    <div class="header">
      <span>Cadastro de Tarefas</span>
    </div>

    <div class="divTable">
      <table>
        <thead>
          <tr>
            <th>Código</th>
            <th>Título</th>
            <th>Descrição</th>
            <th>Data de criação</th>
            <th>Usuário</th>
            <th>Status</th>
            <th>
              <form name="busca" onsubmit="return false" action="#">
                <label>Filtrar por Status:</label>
                  <select name="buscador" style = "margin-left: 30px" onchange="recuperardados()">
                    <option value="S">Selecionar</option>
                    <option value="P">Pendente</option>
                    <option value="C">Concluido</option>
                  </select>
              </form>
            </th>
            <th style="text-align: center"><a href="cadastro_tarefa.php"><button id="new">Adicionar</button></a></th>
          </tr>
        </thead>
        <tbody id="conteudo">
          <?php
          while ($listagem = mysqli_fetch_array($lista)) {
            $codigo = $listagem['codigo'];
            $titulo = $listagem['titulo'];
            $descricao = $listagem['descricao'];
            $data = $listagem['data'];
            $status = $listagem['status'] == "P" ? "Pendente" : "Concluído";
            $statusColor = $listagem['status'] == "P" ? "#c78f16" : "green";
          ?>
            <tr>
              <td><?php echo $codigo; ?></td>
              <td><?php echo $titulo; ?></td>
              <td><?php echo $descricao; ?></td>
              <td><?php echo $data; ?></td>
              <td style = "text-align: center;
    padding: 5px;
    text-align: start;
    margin-bottom: 50px;"><?php echo $usuario; ?></td>
              <td style="color: <?php echo $statusColor; ?>;"><?php echo $status; ?></td>
              <td>
                <form name="utilitarios" action="utilitarios.php" method="POST">
                  <input type="text" name="codigo" id="codigo" value="<?php echo $codigo; ?>" style="display: none">
                  <input class="botao" type="submit" name="funcao" id="botaolist" value="Excluir">
                  <input class="botao" type="submit" name="funcao" id="botaolist" value="Alterar">
                  <?php if ($status != "Concluído") { ?>
                    <input class="botao" type="submit" name="funcao" id="botaolist" value="Entregar Tarefa">
                  <?php } else { ?>
                    <input class="botao" type="submit" name="funcao" id="botaolist" value="Estornar Entrega">
                  <?php } ?>
                </form>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>

    <div class="modal-container">
      <div class="modal">
        <form action="addtarefa.php" method="POST">
          <label for="m-titulo">Título</label>
          <input id="m-titulo" type="text" required />

          <label for="m-descricao">Descrição</label>
          <textarea id="m-descricao" required></textarea>
          <label for="radio">Status</label>
          <div id="radio">
            <label for="m-statusPendente">Pendente</label>
            <input id="m-statusPendente" type="radio" required />
            <label for="m-statusConcluida">Concluída</label>
            <input id="m-statusConcluida" type="radio" required />
          </div>
          <button id="btnSalvar">Salvar</button>
        </form>
      </div>
    </div>
  </div>
</body>

</html>
