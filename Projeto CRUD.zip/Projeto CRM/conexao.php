<?php


$conexao = mysqli_connect('127.0.0.1','root','','bdtarefas') or die ('Erro ao conectar ao BD');


?>
