<?php

    include ("conexao.php");
    session_start();
require("teste_conexao.php");

    $usuario = $_SESSION['usuario'];
    $codigo_tarefa = $_SESSION['codigo_tarefa'];

    $sql = "SELECT * FROM tbtarefa WHERE idusuario=(SELECT codigo from tbusuarios where nome='$usuario') AND codigo = $codigo_tarefa";
    $lista = mysqli_query($conexao, $sql);
    $listagem = mysqli_fetch_array($lista);

    $titulo = $listagem['titulo'];
    $descricao = $listagem['descricao'];
    $status = $listagem['status'];

?>



<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edição de Tarefas</title>
    <link rel="icon" type="image/x-icon" href="images/cadastro.png">
    <link rel="stylesheet" href="css\style.css">
    <script src="js/addtarefa.js"></script>
</head>
<body>
    <header>
    </header>
        <form method="POST" action = "utilitarios.php" name = "cadtarefa" id="form" onsubmit="return validaCadastroTarefa()">
            <div id="interface">
                <h1>Edição de Tarefas</h1 id="titulo">
                    <label for="name" class="login"><strong>Título da Tarefa:</strong></label></br>
                    <input type="text"  value="<?php echo($titulo) ?>"  class="campo" name="titulo" id="titulo"></br>

                    <label for="senha" class="login"><strong>Descrição: </strong></label></br>
                    <textarea name="descricao" id="descricao" rows="5" cols="27" style="resize: none"><?php echo($descricao) ?></textarea><br>
                    <br>

                    <label for="status" class="login"><strong>Status: </strong></label></br>
                    <select class="campo" name="status" id="status">
                    <?php

                        if($status == "P") {

                    ?>
                        <option value="P">Pendente</option>
                        <option value="C">Concluída</option>
                        <option value="Selecionar">Selecione o Status</option>
                    
                    <?php } else { ?>
                
                        <option value="C">Concluída</option>
                        <option value="P">Pendente</option>
                        <option value="Selecionar">Selecione o Status</option>
                    
                    <?php } ?>
                    
                    </select><br>

                    <div id="login"> 
                        <button type="submit" class="botao" name="funcao" style="width: 200px;" value="Alterado">Salvar alteração</button>
                    </div> 
            </div>

        </form>
    <footer>
    </footer>
</body>
</html>

