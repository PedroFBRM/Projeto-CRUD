<?php



require("conexao.php");
session_start();

unset($_SESSION['usuario']);
unset($_SESSION['codigo_tarefa']);
mysqli_close($conexao);

header("Location: index.php");

?>
