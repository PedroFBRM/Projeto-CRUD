<?php
    
    session_start();
    
    

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="icon" type="image/x-icon" href="images/login.png">
    <link rel="stylesheet" href="css\style.css">
    <script src="js\index.js"></script>
</head>
<body>
    <header>
    </header>
        <form action="login.php" method="POST" id="form" onsubmit="return validaEntrada()">
            <div id="interface">
                <h1>Login</h1 id="titulo">
                    <label for="name" class="login"><strong>Nome de Usuário:</strong></label></br>
                    <input type="text" class="campo" name="nome" id="nome"></br>
                    <label for="senha" class="login"><strong>Senha: </strong></label></br>
                    <input type="password" class="campo" name="senha" id="senha"></br>
                    <div id="login"> 
                        <button type="submit" class="botao" style="width: 200px;">Logar</button>
                    </div>
            </div>
            <div id="cadastrar">
                    <label style="font-size: smaller; color: #686868;"> <strong>Não tem conta?</strong></label>     
                    <button type="button" class="botao" name="cadastrar" id="cadastrar"><a rel="" href="cadastro.php">Cadastre-se</a></button>
            </div>
        </form>
    <footer>
    </footer>
</body>
</html>

