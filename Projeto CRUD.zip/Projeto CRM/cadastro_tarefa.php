<?php

session_start();
require("teste_conexao.php");

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Tarefas</title>
    <link rel="icon" type="image/x-icon" href="images/cadastro.png">
    <link rel="stylesheet" href="css\style.css">
    <script src="js/addtarefa.js"></script>
</head>
<body>
    <header>
    </header>
        <form method="POST" action = "addtarefa.php" name = "cadtarefa" id="form" onsubmit="return validaCadastroTarefa()">
            <div id="interface">
                <h1>Cadastro de Tarefas</h1 id="titulo">
                    <label for="name" class="login"><strong>Título da Tarefa:</strong></label></br>
                    <input type="text" class="campo" name="titulo" id="titulo"></br>

                    <label for="senha" class="login"><strong>Descrição: </strong></label></br>
                    <textarea name="descricao" id="descricao" rows="5" cols="27" style="resize: none"></textarea><br>
                    <br>

                    <label for="status" class="login"><strong>Status: </strong></label></br>
                    <select class="campo" name="status" id="status">
                        <option value="Selecionar">Selecione o Status</option>
                        <option value="P">Pendente</option>
                        <option value="C">Concluída</option>
                    </select><br>

                    <div id="login"> 
                        <button type="submit" class="botao" style="width: 200px;">Cadastrar</button>
                    </div>
            </div>

        </form>
    <footer>
    </footer>
</body>
</html>

