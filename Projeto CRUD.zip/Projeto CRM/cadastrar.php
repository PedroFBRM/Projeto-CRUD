<?php

    include("conexao.php");

    $nome = $_POST['nome'];

    if($nome != "") {

      $sql = $conexao->prepare("SELECT nome FROM tbusuarios WHERE nome = ?");
      $sql->bind_param("s",$nome);
    
    $get = $sql->execute();

    if($get) {

      $resultado = $sql-> get_result();
      $resultadoFinal = mysqli_num_rows($resultado);

            if($resultadoFinal > 0) {
            
              echo("<script>window.alert('Cadastro já existe! Verificar Nome!')</script>");
              echo("<script>window.location.href='cadastro.php'</script>");
              
            }

    } else {

      die("Erro ao realizar pesquisa!");
   
    }

  }


    $senha = $_POST['senha'];
    $genero = $_POST['genero'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];
    $endereco = $_POST['endereco'];
    $data_nascimento = $_POST['data_nascimento'];
    
    date_default_timezone_set('America/Sao_Paulo');
    $data_cadastro = date('Y-m-d');



    switch($genero) {

      case "Masculino":

          $genero="M";

        break;

     case "Feminino":

          $genero="F";

        break;
     case "Outro":

          $genero="O";

        break;
      case "Prefiro não especificar":

          $genero="S";
      break;

    }


  

    $sql = "INSERT INTO tbusuarios (nome, senha, genero, telefone, email, endereco, data_nascimento, data_cadastro) VALUES 
    ('$nome', '$senha', '$genero', '$telefone', '$email', '$endereco', '$data_nascimento', '$data_cadastro')";
   
 
    $cadastro = mysqli_query($conexao,$sql) or die('Em caso de erro nos contate');
  


   if ($cadastro) {
   
      echo("<script>window.alert('Cadastro realizado com sucesso!')</script>");
      echo("<script>window.location.href='Index.php'</script>");
  
   } else {

        die("Erro ao registrar");

   }

?>
